![alt tag](http://i.imgur.com/xEzMkd7.jpg)



# SurvivalGames  V3.0.6
SurvivalGames plugin for ImagicalMine - Genysis, tradotto in italiano da GeoZDev

# Commands:

**/sg** Displays all of the possible SurvivalGamesV3 commands!

# Authors
**@austina1212 is the original author, but @ImagicalGamer took over**

**@remote_vase has also been helping out with ImagicalMine related things**

**@Taki21 & @EpicSteve33 has been helping with some tweaks here and there**

# CopyRight
The license does not state the following but these terms apply to SurvivalGamesV3

- **Under no circumstances do you have the right to modify and/or re-distribute this resource!**

# Gitter Chat
Want to chat? Join our

[![Join the chat at https://gitter.im/EpicSteve33/SurvivalGames](https://badges.gitter.im/EpicSteve33/SurvivalGames.svg)](https://gitter.im/EpicSteve33/SurvivalGames?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
